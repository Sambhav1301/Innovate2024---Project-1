package com.game.task1;

import java.util.Scanner;
import java.util.Random;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("**********************************");
        System.out.println("*                                *");
        System.out.println("*       Number Mystery Quest     *");
        System.out.println("*                                *");
        System.out.println("**********************************");
        System.out.println();

        System.out.println("Welcome to the Number Mystery Quest!");
        System.out.println("In this quest, you will embark on a journey to guess a number within a range.");
        System.out.println();

        System.out.print("Enter the lower bound of the number range: ");
        int lowerBound = scanner.nextInt();

        System.out.print("Enter the upper bound of the number range: ");
        int upperBound = scanner.nextInt();

        int maxAttempts = 5;

        int targetNumber = random.nextInt(upperBound - lowerBound + 1) + lowerBound;
        int attempts = 0;
        boolean guessedCorrectly = false;

        System.out.println("Your mission is to guess the mysterious number I've chosen between " + lowerBound + " and " + upperBound + ".");
        System.out.println("You have " + maxAttempts + " attempts to solve the mystery. Let the quest begin!");
        System.out.println();

        while (attempts < maxAttempts) {
            System.out.print("Enter your guess: ");
            int guess = scanner.nextInt();
            attempts++;

            if (guess == targetNumber) {
                guessedCorrectly = true;
                break;
            } else if (guess < targetNumber) {
                System.out.println("Too low! Aim higher, brave adventurer.");
            } else {
                System.out.println("Too high! A bit lower, courageous one.");
            }
        }

        if (guessedCorrectly) {
            System.out.println("Congratulations, brave adventurer! You've successfully solved the Number Mystery Quest in " + attempts + " attempts.");
            System.out.println("The mysterious number was indeed " + targetNumber + ". Well done!");
        } else {
            System.out.println("Alas, brave adventurer, your attempts have been exhausted.");
            System.out.println("The Number Mystery remains unsolved. The mysterious number was " + targetNumber + ".");
            System.out.println("Perhaps another adventurer will succeed where you did not.");
        }

        scanner.close();
    }
}
